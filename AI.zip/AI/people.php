<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>手工ai</title>
    <link href="people.css" rel="stylesheet">
</head>
<body>

<div id="chat-container">
    <div id="chat-messages"></div>
    <div class="user-input">
        <form action="people.php?need=<?php echo $_GET['need']?>&consultMethod=<?php echo $_GET['consultMethod']?>" method="post">
            <input type="text" name="question" class="input-text" placeholder="请输入您的问题...">
            <button type="submit" class="send-button">发送</button>
        </form>
        <form style="all: unset" action="ai.php?need=<?php echo $_GET['need'];?>" method="post">
            <button style="border:unset;background-color:unset;color:blue" type="submit">返回</button>
        </form>
    </div>
</div>

<script>
    var conversation = [];

    function sendMessage(inputText) {
        if (inputText.trim() === "") return;

        appendMessage("user", inputText);

        // Clear the input field
        document.querySelector(".input-text").value = "";
    }

    //        appendMessage("ai", aiResponse, true);
    function appendMessage(sender, message, showMoreButton) {
        var chatMessages = document.getElementById("chat-messages");
        var newMessage = document.createElement("div");
        newMessage.className = "message";

        if (sender === "user") {
            newMessage.innerHTML = "<div class='user-message'><strong>你:</strong> " + message + "</div>";
        } else {
            newMessage.innerHTML = "<div class='system-message'><strong>GPT:</strong> " + message + "</div>";
        }

        conversation.push({ sender, message });

        chatMessages.appendChild(newMessage);

        // Scroll to the bottom to show the latest message
        chatMessages.scrollTop = chatMessages.scrollHeight;

        if (showMoreButton) {
            addMoreButton();
        }
    }

    function addMoreButton() {
        var chatMessages = document.getElementById("chat-messages");
        var moreButton = document.createElement("button");
        moreButton.className = "more-button";
        moreButton.textContent = "请告诉我更多";
        moreButton.onclick = function () {
            //var httpRequest = new XMLHttpRequest();//第一步：创建需要的对象
            //httpRequest.open('POST', 'people.php?need=<?php echo $_GET['need']?>&consultMethod=<?php echo $_GET['consultMethod']?>', true); //第二步：打开连接
            //httpRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded");//设置请求头 注：post方式必须设置请求头（在建立连接后设置请求头）
            //httpRequest.send('question=%E8%AF%B7%E5%91%8A%E8%AF%89%E6%88%91%E6%9B%B4%E5%A4%9A');//发送请求 将情头体写在send中
            //location.reload();

            var additionalResponse = "别点了，没实现这玩意，老老实实在下面输入";
            appendMessage("ai", additionalResponse, true);
        };

        chatMessages.appendChild(moreButton);

        // Scroll to the bottom to show the button
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
</script>
</body>
</html>


<?php
    include 'function.php';
    panduan();
    session_start();
    if(empty($_GET['need'])) header("Location:choose.php");
    if($_POST['question']){
    //获取原先的记录
    $people_user_arr = $_SESSION['people_user'];
    $people_assistant_arr = $_SESSION['people_assistant'];

    //获取问题并更新维护数组
    $question = $_POST['question'];

    $people_user_arr[] = $question;

    $ai = new test();
    $ai->xfyun($people_user_arr,$people_assistant_arr);

    //保存记录
    if($ai->ans!=null) $people_assistant_arr[] = $ai->ans;
    $_SESSION['people_user'] = $people_user_arr;
    $_SESSION['people_assistant'] = $people_assistant_arr;
    $pdo = getPDO();
    //给数据库插入历史数据
    $pdo->exec("INSERT INTO ai VALUES ('$question')");

    //遍历数组，进行js代码渲染
    for($i=0;$i<count($people_user_arr);$i++){
        echo '<script>';
        echo 'sendMessage('.json_encode($people_user_arr[$i]).');'; // 调用 JavaScript 函数
        if($i<count($people_assistant_arr)-1)
            echo 'appendMessage("ai",'.json_encode($people_assistant_arr[$i]).');';
        else
            echo 'appendMessage("ai",'.json_encode($people_assistant_arr[$i]).',true);';
        echo '</script>';
    }

}
?>



