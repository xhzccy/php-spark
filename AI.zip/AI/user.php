<!DOCTYPE html>
<html lang="en">
<head>
    <title>用户管理</title>
    <link rel="stylesheet" href="user.css">
</head>
<body>
<h1>用户管理</h1>

<div class="container">
    <form action="user.php" method="POST">
        <label for="username">用户名:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">密码:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">添加用户</button>
    </form>

    <table>
        <thead>
        <tr>
            <th>用户名</th>
            <th>操作</th>
        </tr>
        </thead>
        <tbody>
        <?php

        session_start();
        include 'function.php';
        panduan();
        $pdo = getPDO();




        ?>
        </tbody>
    </table>
</div>
</body>
</html>
