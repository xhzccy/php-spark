<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="login.css">
    <title>登录</title>
</head>
<body>
<div class="container">
    <h1>登录</h1>
    <form action="login.php" method="post">
        <div class="form-control">
            <input type="text" id="user" name="user" required>
            <label>用户名</label>
            <!-- <label>
              <span style="transition-delay: 0ms">E</span>
                <span style="transition-delay: 50ms">m</span>
                <span style="transition-delay: 100ms">a</span>
                <span style="transition-delay: 150ms">i</span>
                <span style="transition-delay: 200ms">l</span>
          </label> -->
        </div>

        <div class="form-control">
            <input type="password" id="password" name="password" required>
            <label>密码</label>
        </div>

        <button class="btn" type="submit">登录</button>

        <p></p>
    </form>
</div>
<script src="login.js"></script>
</body>
</html>

<?php
session_start();
if (!isset($_SESSION['login'])) {
    $_SESSION['login'] = false;
}

$user = $_POST['user'];
$password = $_POST['password'];
if(empty($user)&&empty($password)){
    if(!$_SESSION['login']) {
        $_SESSION['login'] = true;
        exit();
    }
    die("需要用户名和密码");
}
else if(empty($user)) {
    die("用户名不为空");
}
else if(empty($password)) {
    die("密码不为空");
}


if(!preg_match('/^dgut\d{13}$/',$user)){
    die("不存在该用户");
}
$tmp = substr($user,-6,6);
if($password!==$tmp){
    die("密码错误");
}

$_SESSION['user'] = $user;
$_SESSION['password'] = $password;
header("Location:choose.php");
