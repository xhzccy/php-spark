<?php
include 'function.php';
panduan();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>选择界面</title>
    <link href="color.css" rel="stylesheet">
</head>
<body>

<!-- 用户选择咨询方式 -->
<form action="ai.php" method="get">
    <label for="need">选择是否需要联系上下文:</label>
    <select name="need" id="need">
        <option style="display:none"></option>
        <option value="2">需要</option>
        <option value="1">不需要</option>
    </select>
    <br>
    <button type="submit">提交</button>
</form>

