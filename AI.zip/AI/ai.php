<?php
include 'function.php';
session_start();
panduan();

//连接数据库

$consult_method=$_GET['consultMethod'];
?>

<?php
if($consult_method==null){
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>智能客服</title>
    <link href="color.css" rel="stylesheet">
</head>
<body>
<h1>智能客服</h1>

<!-- 用户选择咨询方式 -->
<form action="ai.php?" method="get">
    <!--隐藏传送need值，用post后面加url也行-->
    <input type="hidden" name="need" value="<?php echo $_GET['need']; ?>">
    <label for="consultMethod">选择咨询方式:</label>
    <select name="consultMethod" id="consultMethod">
        <option style="display:none"></option>
        <option value="manual">智能客服手动问答方式</option>
        <option value="userChoice">用户手动选择答案</option>
    </select>
    <br>
    <button type="submit">提交</button>
</form>
<form style="all: unset" action="choose.php" method="post">
    <button style="border:unset;background-color:unset;color:salmon" type="submit">重新选择上下文连接关系</button>
</form>

<!-- 显示历史咨询记录 -->
<h2>历史咨询记录</h2>
<form style="all: unset" action="ai.php?need=<?php echo $_GET['need']?>&del=1" method="post">
    <button style="border:unset;background-color:unset;color:blue" type="submit">清空历史记录</button>
</form>
<ul>
<?php
    if(empty($_GET['need'])) header("Location:choose.php");
    if(isset($_GET['del'])){
        $del = $_GET['del'];
        if($del==1){
            $pdo = getPDO();
            $pdo->exec("delete from ai");
        }
        unset($_SESSION['ai_assistant']);
        unset($_SESSION['ai_user']);
        unset($_SESSION['people_assistant']);
        unset($_SESSION['people_user']);
    }

    $pdo = getPDO();
    $sql = $pdo->query("select * from ai");
    $row = $sql->fetch();
    if($row){
        while($row){
            echo "<li>$row[0]</li>";
            $row = $sql->fetch();
        }
    }
    ?>
    <!-- PHP代码用于查询数据库并展示历史记录 -->
</ul>

</body>
</html>
    <?php
}
?>


<?php
//智能问答
if($consult_method=="manual"){
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>智能ai</title>
    <link href="ai.css" rel="stylesheet">
</head>
<body>


<div class="question-container">
    <label for="questionInput">请输入您的问题:</label>
    <form action="ai.php?need=<?php echo $_GET['need']?>&consultMethod=<?php echo $consult_method?>" method="post">
    <input type="text" id="questionInput" name="question" placeholder="在这里输入您的问题">
        <?php
        if(empty($_GET['need'])) header("Location:choose.php");
        if($_POST['question']){
            //获取原先的记录
            $ai_user_arr = $_SESSION['ai_user'];
            $ai_assistant_arr = $_SESSION['ai_assistant'];

            //获取问题并更新维护数组
            $question = $_POST['question'];
            $ai_user_arr[] = $question;

            $ai = new test();
            $ai->xfyun($ai_user_arr,$ai_assistant_arr);
            echo "<p>$ai->ans</p>";

            //保存记录
            if($ai->ans!=null) $ai_assistant_arr[] = $ai->ans;
            $_SESSION['ai_user'] = $ai_user_arr;
            $_SESSION['ai_assistant'] = $ai_assistant_arr;

            $pdo = getPDO();
            //给数据库插入历史数据
            $pdo->exec("INSERT INTO ai VALUES ('$question')");
        }
        ?>
    <button type="submit">提交</button>
    </form>
    <form style="all: unset" action="ai.php?need=<?php echo $_GET['need'];?>" method="post">
        <button style="border:unset;background-color:unset;color:skyblue" type="submit">返回</button>
    </form>

</div>

</body>
</html>
<?php
}
?>


<?php
//手工选择
if($consult_method=="userChoice"){
    $url = "people.php?need=".$_GET['need']."&consultMethod=".$consult_method;
    header('Location: '.$url);
}

?>


